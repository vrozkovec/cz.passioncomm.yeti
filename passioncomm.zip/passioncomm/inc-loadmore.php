<div class="load-more visible-xs visible-sm">
	<div class="container">
		<div class="row visible-xs visible-sm">
			<div class="col-xs-12">
				<div class="in-content-leaf">
					<div class="orange-leaf">
						<div class="content">
							<div>
								<img src="css/img/preloader-white.gif" class="active" /> <img
									src="css/img/preloader.gif" class="pasive" />
							</div>
							Load more work
						</div>
						<div class="shadow"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>