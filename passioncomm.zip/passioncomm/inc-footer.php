	
	<footer>
		<div class="container">
			© Passion Communications s.r.o. 2014 <span class="hidden-xs">|</span><span class="visible-xs"><br /></span>  <a href="#">Administration</a> | <a href="#">Contact Us</a>
		</div>
	</footer>
	
	<span class="screen-size-desktop"></span>
	<span class="screen-size-mobile"></span>
	<span class="screen-size-tablet"></span>
	
	<script
		src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
	<script>
		window.jQuery
				|| document
						.write('<script src="js/vendor/jquery-1.10.1.min.js"><\/script>')
	</script>

	<script src="js/vendor/bootstrap.min.js"></script>

<!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
<!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
	
	<script src="js/plugins.js"></script>
	<script src="js/main.js"></script>

	<script>
		var _gaq = [ [ '_setAccount', 'UA-XXXXX-X' ], [ '_trackPageview' ] ];
		(function(d, t) {
			var g = d.createElement(t), s = d.getElementsByTagName(t)[0];
			g.src = '//www.google-analytics.com/ga.js';
			s.parentNode.insertBefore(g, s)
		}(document, 'script'));
	</script>
