	<div class="tophead">
		<div class="container">
			<div class="row">
				<div class="col-xs-1 visible-xs arrow"><a href="#"><i class="icon-arrow-left"></i></a></div>
				<div class="col-xs-10 col-sm-5 logo"></div>
				<div class="col-xs-1 visible-xs arrow"><a href="#"><i class="icon-arrow-right"></i></a></div>
				<div class="col-sm-7 hidden-xs slogan">
					We promise that everything we do,<br /> we do with passion.
				</div>
			</div>
		</div>
	</div>
