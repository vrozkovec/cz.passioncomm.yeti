/css/bootstrap-less-src - zdrojové soubory které byly použity pro vygenerování Bootstrapu
/css/main.less - LESS soubor, který byl použitý k vygenerování hlavního CSS main.css a main.min.css
/blog.php a /blog.2.php - různé umístění sekce Explore more work





